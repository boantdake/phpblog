<?php include 'includes/header.php'; ?>
<?php
	$id = $_GET['id'];

	//Create DB Object
	$db = new Database();
	
	//Create Query
	$query = "SELECT * FROM posts WHERE id = ".$id;
	//Run Query
	$post = $db->select($query)->fetch_assoc();//notice how I changed it to just post because it is only grabbing one. fetch_assoc() is also necessary for this to run.
	
	//Create Query
	$query = "SELECT * FROM categories";
	//Run Query
	$categories = $db->select($query);
?>
<div class="blog-post"><!--No while loop in this one because of the single post format.  the only diffence in this format is simply using post instead of row like in the post-->
            <h2 class="blog-post-title"><?php echo $post['title']; ?></h2>
            <p class="blog-post-meta"><?php echo formatDate($post['date']); ?> by <a href="#"><?php echo $post['author']; ?></a></p>
			<p class="blog-text"><?php echo $post['body']; ?></p>       
          </div><!-- /.blog-post -->	      
<?php include 'includes/footer.php'; ?>