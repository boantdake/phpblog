<?php
	define('DB_HOST','localhost'); //using model define('CONSTANT','value');
	define('DB_USER','root');
	define('DB_PASS','jackass9');
	define('DB_NAME','phpblog');

	$site_description = "A simple blog to play around with using PHP and other web technologies adding in a bit of Linux Research";