<?php 
	$timezone = "America/New_York";
	date_default_timezone_set($timezone);//you have to set your date in order to use the formatdate function helper in php

	//Format the date
	function formatDate($date){
		return date('F j, Y, g:i a',strtotime($date));
	}
	function shortenText($text, $chars = 200){
		$text = $text." ";
		$text = substr($text, 0, $chars);//this is the start position
		$text = substr($text, 0, strrpos($text, ' '));//this is so the text isnt cut off in the middle of a word
		$text = $text."...";//this spits out that there is more to read
		return $text;
	}

 