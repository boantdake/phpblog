<?php include 'includes/header.php'; ?>
<?php //this is where the data will be pushed to the database
	

	$db = new Database();//the db object is placed up here in these tags in order to access the object with this function as well this is a scripted language (it reads top to bottom)


	if(isset($_POST['submit'])){
		//assign variables
		$name = mysqli_real_escape_string($db->link, $_POST['name']);///the perameters are set as follows (database connection variable, and then whatever the input is) this is a method of encryption its not stellar but it does the job.


		//simple validations
		if ($name == '') {
			//set errors
			$error = "Please fill out required fields";
		} else{
			$query = "INSERT INTO categories
						(name)
						VALUES('$name')";
			$update_row = $db->update($query);
		}

	}

 ?>


<form role="form" method="post" action="add_category.php">
  <div class="form-group">
    <label>Category Name</label>
    <input name="name" type="text" class="form-control" id="categoryname" placeholder="Enter Category">
  </div>
  <div>
  <button name="submit" type="submit" class="btn btn-default">Submit</button>
  <a href="index.php" class="btn btn-danger">Cancel</a> 
  </div>
</form>
<?php include 'footer.php'; ?>
