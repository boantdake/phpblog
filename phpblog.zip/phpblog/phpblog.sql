-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 29, 2016 at 10:31 PM
-- Server version: 5.7.16-0ubuntu0.16.04.1
-- PHP Version: 7.0.8-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'News'),
(2, 'Events'),
(3, 'Tutorials'),
(4, 'Misc');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category`, `title`, `body`, `author`, `tags`, `date`) VALUES
(1, 1, 'The Name is Se7en not 6.', '<p>The current stable release uses the version number PHP 5.6. After some dispute the development team decided they would omit the PHP 6 name for the next major release. PHP 6 already existed in the past as an experimental project but never reached the production phase.</p>', 'Bo Dake', 'PHP 7 News', '2016-11-04 01:51:06'),
(2, 1, 'PHP 7 News Update!', 'The most easily recognizable advantage of the new PHPNG engine is the significant performance improvement. The development team of PHPNG refactored the Zend Engine, and remarkably optimized memory usage.', 'Bo Dake', 'PHP 7 News, PHP Speed', '2016-11-04 01:51:06'),
(6, 3, 'Ecommerce!', 'So there are alot of uses for PHP.  The most important that I have been able to fathom is the use of PHP in shopping carts like Open Cart or Magento.  Several other opensource shopping carts as well as blog spaces and other Content Management Systems.  Businesses, often smaller platforms like mom and pop shops use CMS\'s that are designed specifically for their purposes like open cart for an open source or free way to sell their items online like the Amazon service without the inspection period that is associated with it.\r\n\r\nThere are several different versions of shopping carts that use PHP another version of the shopping cart system can be used with Wordpress which is called WooCommerce.  WooCommerce is great minus of course the amount of plugins that is required in order to use it.  The more plugins you employ with your wordpress installation the slower the process is.  Another issue that is apparent with wordpress is the apparent lack of security involved with it.  Wordpress is insanely popular due to its ease of use as a blogging system which its great for but other than that I would not venture to say that putting any sort of enterprise system on a wordpress platform.', 'Bo Dake', 'PHP, Ecommerce Platforms', '2016-11-13 23:05:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
